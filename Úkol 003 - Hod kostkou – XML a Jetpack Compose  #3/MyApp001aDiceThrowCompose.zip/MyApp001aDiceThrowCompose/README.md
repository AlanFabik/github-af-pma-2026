# MyApp001aDiceThrowCompose

Převod původní aplikace z XML na strukturu **Empty Activity / Jetpack Compose**.

## Otevření

1. Rozbal ZIP a v Android Studiu zvol **Open** → složku `MyApp001aDiceThrowCompose` (obsahuje `settings.gradle.kts`).
2. Nech proběhnout Gradle Sync. Je potřeba internet pro stažení závislostí.
3. V SDK Manageru nainstaluj **Android SDK Platform 36**. Gradle JDK nastav na **17** (případně použij kompatibilní Embedded JDK Android Studia).
4. Vyber emulátor nebo telefon s Androidem 7.0+ a spusť aplikaci tlačítkem Run.

Není potřeba vytvářet další projekt. Tento projekt už obsahuje Compose konfiguraci.

## Co se změnilo

- `MainActivity` dědí z `ComponentActivity` a používá `setContent`.
- `DiceThrowScreen()` skládá rozhraní pomocí `Column`, `Text` a `Button`.
- `DiceThrowTheme()` definuje Material 3 barvy v Kotlinu.
- Původní `activity_main.xml`, `findViewById` a AppCompat byly odstraněny.
- Zůstává nadpis, šest symbolů kostky, barvy a animace 10 × 250 ms. Tlačítko je během hodu vypnuté.
- `rememberSaveable` uchová aktuální hodnotu při otočení telefonu. Probíhající hod se při obnovení Activity zastaví a tlačítko se znovu zapne.
- `@Preview` umožňuje náhled bez spuštění emulátoru.
- Původní identifikátor aplikace a package `com.example.myapp001adicethrowxml` zůstávají zachované kvůli návaznosti na původní aplikaci.

XML zůstává pouze pro AndroidManifest, textové zdroje, systémové téma, ikony a zálohování. Rozvržení obrazovky je celé v Kotlinu.

## Konfigurace a ověření

Projekt používá explicitně sladěnou konfiguraci AGP 8.13.2, Gradle 8.13, Kotlin / Compose Compiler 2.2.21, Compose BOM 2025.12.00 a SDK 36. Nahrazuje původní konfiguraci AGP 9.4.1 / SDK 37, aby používal běžnou strukturu s Kotlin Android pluginem. Minimální SDK 24 zůstává zachované.

```bash
./gradlew assembleDebug testDebugUnitTest
./gradlew connectedDebugAndroidTest
```

Druhý příkaz vyžaduje připojený telefon nebo spuštěný emulátor. UI testy kontrolují úvodní obrazovku, vypnutí tlačítka během animace a platný výsledek hodu.

V prostředí převodu nebylo dostupné Android SDK a stažení Gradlu blokovala síť. Byla provedena pouze statická kontrola projektu; sestavení a UI testy je potřeba spustit v Android Studiu.

Oficiální dokumentace:
- https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler
- https://developer.android.com/build/releases/gradle-plugin
- https://developer.android.com/blog/posts/whats-new-in-the-jetpack-compose-december-release
